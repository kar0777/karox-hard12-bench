"""KaroX 5.0: a local agent runtime with one compact terminal client.

The release keeps the verified agent kernel (typed tools, risk and capability
policy, durable sessions, MCP, browser/desktop control and the hosted bridge)
while leaving the v5 laboratory's orchestration experiments out of the stable
surface.
"""

__version__ = "5.0.0"