"""Proposed first-party HARD20/Wsl action contract (no process launcher).

This module is intentionally *not* connected to command.run/start. Hosted
developer commands must keep rejecting WSL and all opaque shell wrappers.
A separately reviewed native KaroX action can use this declarative contract
after genuine user approval and provider/WSL checks. No auth or model calls
happen here.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

EXACT_MODEL = "deepseek-ai/DeepSeek-V4.1-Flash-1017"
TASK_ID = "real-three-orbitcontrols-35003-v2"
DISTRO = "Ubuntu"
ARMS = frozenset({"karox5", "opencode_v2", "deepseek_harness"})
_LABEL = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}\Z")
TRUSTED_WSL_PYTHON = "/home/ekono/.cache/karox-fair-linux-20261108/eval-venv/bin/python"
TRUSTED_RUN_SCRIPT_SUFFIX = "audit/hard20_live_one.py"
TRUSTED_ATTEST_SCRIPT_SUFFIX = "audit/hard20_zero_provider_wsl_probe.py"


class NativeWslDenied(ValueError):
    """Request requires a separately permissioned native action."""


@dataclass(frozen=True)
class NativeRunTicket:
    operation: Literal["attest", "run_one"]
    distro: str
    arm: str | None
    label: str | None
    model_id: str
    task_id: str
    wsl_python: str
    wsl_script: str
    requires_provider_rotation_check: bool
    requires_isolation_attestation: bool
    requires_exclusive_resource_slot: bool
    permit_generic_command_start: bool = False


def require_operator_authority(
    *,
    host_native_capability_enabled: bool,
    explicit_user_approval_verified_by_host: bool,
) -> None:
    """No untrusted request field can grant or synthesize these host facts."""
    if not host_native_capability_enabled:
        raise NativeWslDenied("HARD20 native WSL action not available in bridge")
    if not explicit_user_approval_verified_by_host:
        raise NativeWslDenied("HARD20 user approval required in host UI")


def make_ticket(
    *,
    repo_root: Path,
    operation: Literal["attest", "run_one"],
    host_native_capability_enabled: bool,
    explicit_user_approval_verified_by_host: bool,
    arm: str | None = None,
    label: str | None = None,
    model_id: str = EXACT_MODEL,
) -> NativeRunTicket:
    """Build a *declarative*, fixed-scope ticket, not a runnable argv.

    For run_one the separate native implementation must check provider
    revocation with independent issuer evidence and run real WSL bwrap
    attestation before invoking any paid CLI. Neither is accepted from model
    client arguments. The action must preserve one-heavy-job resource locking.
    """
    require_operator_authority(
        host_native_capability_enabled=host_native_capability_enabled,
        explicit_user_approval_verified_by_host=explicit_user_approval_verified_by_host,
    )
    if model_id != EXACT_MODEL:
        raise NativeWslDenied("HARD20 exact provider model mismatch")
    if operation not in ("attest", "run_one"):
        raise NativeWslDenied("Unknown native WSL operation")
    if operation == "attest":
        if arm is not None or label is not None:
            raise NativeWslDenied("Zero-provider attestation cannot accept arm or label")
    else:
        if arm not in ARMS or not isinstance(label, str) or not _LABEL.fullmatch(label):
            raise NativeWslDenied("Unsafe benchmark arm or label")
    # The path must point to the selected recovery worktree, never a user
    # project, arbitrary file, symlink or an attacker-provided script.
    if not repo_root.is_dir() or repo_root.is_symlink():
        raise NativeWslDenied("Invalid approved benchmark root")
    if repo_root.name != "hard20-recovery-20261108":
        raise NativeWslDenied("Unapproved benchmark worktree")
    script = repo_root / (
        TRUSTED_ATTEST_SCRIPT_SUFFIX if operation == "attest" else TRUSTED_RUN_SCRIPT_SUFFIX
    )
    if not script.is_file() or script.is_symlink():
        raise NativeWslDenied("Trusted audited benchmark script absent")
    if repo_root.drive.upper() != "D:":
        raise NativeWslDenied("Benchmark must reside on D: worktree")
    source = script.resolve(strict=True)
    if not source.is_relative_to(repo_root.resolve(strict=True)):
        raise NativeWslDenied("Trusted script escaped approved root")
    wsl_path = "/mnt/d/" + source.as_posix().split(":", 1)[1].lstrip("/")
    return NativeRunTicket(
        operation=operation,
        distro=DISTRO,
        arm=arm,
        label=label,
        model_id=EXACT_MODEL,
        task_id=TASK_ID,
        wsl_python=TRUSTED_WSL_PYTHON,
        wsl_script=wsl_path,
        requires_provider_rotation_check=True,
        requires_isolation_attestation=True,
        requires_exclusive_resource_slot=True,
    )
