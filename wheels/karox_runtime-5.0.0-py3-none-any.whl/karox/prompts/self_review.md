Before KaroX accepts finish, review the change once as the project's maintainer would, then call finish again (this review is asked only once):
1. Re-read the task. Every behaviour it asks for or implies -- including exact strings, messages and outputs it shows -- must hold on the current files; probe any you have not observed since your last edit.
2. Same defect elsewhere: sibling methods, other output forms (str/repr/rich), other constructors and round-trips (to_dict/load/copy). Fix them too.
3. Edge cases of the changed code: empty, zero/one/many, first/last, missing or None values. Probe the ones that apply.
4. Conventions: new messages and names match neighbouring code and its tests (capitalisation, punctuation, wording).
5. Scope: undo edits the task does not need (unrelated modules, configuration, existing tests).
If everything already holds, call finish again with the same answer.
