Before KaroX verifies the work, review the change once as the project's maintainer would (this review is asked only once):
1. Re-read the task. Every behaviour it asks for or implies -- including exact strings, messages and outputs it shows -- must hold on the current files; probe any you have not observed since your last edit. If the task names the cause or the intended fix, the change must be that fix at that place, not a guard around the symptom; rework it if not.
2. Same defect elsewhere: variants the task names or hints at but did not test (other spellings or naming styles, "not checked: ..." notes), sibling methods, other output forms (str/repr/rich), other constructors and round-trips (to_dict/load/copy), state the old code carried (offsets, metadata, counts). Fix them too.
3. Edge cases of the changed code: empty, zero/one/many, first/last, missing or None values, boundaries (time zones, DST, encodings). Probe the ones that apply.
4. Errors: keep the module's error path. Invalid or ambiguous input raises what the surrounding code raises for it; never swallow an exception into a sentinel, an empty result or a guess.
5. Conventions: new messages and names match neighbouring code and its tests (capitalisation, punctuation, wording).
6. Scope: undo edits the task does not need (unrelated modules, configuration, existing tests).
Fix what this finds, run the narrowest covering test, then finish. If everything already holds, finish now with the same answer.
