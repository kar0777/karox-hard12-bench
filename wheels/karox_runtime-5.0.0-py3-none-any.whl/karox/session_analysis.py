"""Proof-state readers for a persisted session record.

Small pure functions the engine kernel uses to decide what a session already
proved: which writes happened, what the evidence chain selected, what checks
the completion floor and the chain still owe, and what the model's answer
rests on.
They read only the ``SessionRecord`` the session store checksums, so their
output is as trustworthy as the record itself. Extracted verbatim from the
retired v5 loop so the engine inherits its exact semantics.
"""

from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import completion_gate
from .security import redact
from .sessions import SessionRecord

#: Tools whose successful, non-no-op result counts as a real repository change
#: for the verification chain.
MUTATION_TOOLS: frozenset[str] = frozenset(
    {"repo.write_file", "repo.edit_file", "repo.apply_patch"}
)

#: Who asked Core for a call. A model's own call carries no marker; the
#: harness's finishing checks do, so a reviewer can tell what proved a run.
HARNESS_REQUESTED_BY = "harness_final"

#: Tools whose successful result is something the model actually looked at,
#: as opposed to something it asserted.
INSPECTION_TOOLS: frozenset[str] = frozenset(
    {
        "repo.read_file",
        "repo.read_lines",
        "repo.inspect",
        "repo.search",
        "repo.list_files",
        "disk.scan",
        "disk.plan_cleanup",
        "git.status",
        "git.diff",
        "git.log",
    }
)


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON number is not allowed: {value}")


def _strict_json_loads(value: str) -> Any:
    return json.loads(value, parse_constant=_reject_json_constant)


def safe_arguments(raw: str) -> tuple[str, bool]:
    """Redacted argument text plus whether redaction changed nothing."""
    try:
        value = _strict_json_loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError):
        safe = str(redact(raw))
        return safe, safe == raw
    safe_value = redact(value)
    return (
        json.dumps(safe_value, ensure_ascii=False, sort_keys=True),
        safe_value == value,
    )


def step_count(history: List[Dict[str, Any]]) -> int:
    """Assistant turns that carried a provider response."""
    return sum(
        1
        for entry in history
        if entry.get("role") == "assistant" and entry.get("provider")
    )


def unresolved_model_checks(
    record: SessionRecord, missing: Sequence[str]
) -> list[list[str]]:
    """Exact argv of approved checks the floor still owes a rerun, oldest first."""

    owed = {
        reason[len("unresolved failed check: "):]
        for reason in missing
        if reason.startswith("unresolved failed check: ")
    }
    found: list[list[str]] = []
    for entry in record.provider_history:
        if entry.get("role") != "tool" or entry.get("core_name") != "checks.run":
            continue
        result = entry.get("result")
        data = result.get("data") if isinstance(result, dict) else None
        if not isinstance(data, dict) or data.get("verification_eligible") is not True:
            continue
        argv = data.get("argv")
        if not isinstance(argv, list) or not all(isinstance(a, str) for a in argv):
            continue
        if " ".join(argv) in owed and argv not in found:
            found.append(list(argv))
    return found


_Link = Optional[Dict[str, Any]]


def _chain_links(record: SessionRecord) -> Tuple[_Link, _Link, _Link, _Link]:
    """The last changing write and the check, status and diff that follow it.

    Who asked for a call is recorded, and only the two known authors are
    evidence: the model's own calls, and the harness's finishing checks. An
    unknown author is treated the way an unverified write is, because the
    chain exists to prove what happened, not to collect anything that claims
    it did.
    """
    write: Optional[Dict[str, Any]] = None
    check: Optional[Dict[str, Any]] = None
    status: Optional[Dict[str, Any]] = None
    diff: Optional[Dict[str, Any]] = None
    for entry in record.provider_history:
        if entry.get("role") != "tool" or not isinstance(entry.get("result"), dict):
            continue
        result = entry["result"]
        if result.get("requested_by") not in (None, HARNESS_REQUESTED_BY):
            continue
        data = result.get("data") if isinstance(result.get("data"), dict) else {}
        core_name = entry.get("core_name")
        ok = result.get("ok") is True
        if core_name in MUTATION_TOOLS:
            if ok and data.get("changed") is True:
                write, check, status, diff = result, None, None, None
            elif not ok and data.get("changed") is not False:
                # A failure that may have written leaves bytes nothing proved;
                # one that reports it changed nothing (an edit whose old text
                # was not found) leaves the bytes the chain already covers.
                write, check, status, diff = None, None, None, None
        elif core_name == "checks.run" and write is not None:
            if ok and data.get("verification_eligible") is True:
                check, status, diff = result, None, None
            else:
                check, status, diff = None, None, None
        elif core_name == "git.status" and check is not None:
            status = result if ok else None
        elif core_name == "git.diff" and check is not None:
            diff = result if ok else None
    return write, check, status, diff


def chain_owes_check(record: SessionRecord) -> bool:
    """Whether the chain's last changing write has no passing check after it.

    The floor judges a check by the bytes it covered, and its identity leaves
    scratch artifacts and the run's own harness pages out; the chain restarts
    at every changing write. A probe written after the last check, to collect
    fresh observations for a finish, therefore leaves a check the floor calls
    current and a chain without one. Git reads cannot close that gap; only a
    check that runs after the write can. A text-only change owes no check.
    """

    if completion_gate.docs_only(record):
        return False
    write, check, _status, _diff = _chain_links(record)
    return write is not None and check is None


def _no_start_revision(record: SessionRecord) -> bool:
    start = getattr(record, "git_baseline", None)
    return isinstance(start, dict) and start.get("reason") in ("not-a-repository", "git-unavailable")


def evidence_chain(record: SessionRecord) -> bool:
    """Whether the record holds a complete write -> check -> status/diff chain."""

    write, check, status, diff = _chain_links(record)
    if completion_gate.docs_only(record):
        # No behavioral obligation for text; keep persisted change/review evidence.
        status = diff = None
        for entry in record.provider_history:
            result = entry.get("result") or {}
            if entry.get("core_name") in MUTATION_TOOLS:
                status = diff = None
            elif result.get("ok") and result.get("requested_by") in (None, HARNESS_REQUESTED_BY):
                if entry.get("core_name") == "git.status":
                    status = result
                elif entry.get("core_name") == "git.diff":
                    diff = result
        selected = (write, status, diff)
    elif _no_start_revision(record):
        # No git at the start: status and diff can never succeed, and the
        # write -> check links are the whole chain there is.
        selected = (write, check)
    else:
        selected = (write, check, status, diff)
    if any(item is None for item in selected):
        return False
    persisted_ids = {
        item.get("evidence_id")
        for item in record.evidence
        if isinstance(item, dict)
    }
    for result in selected:
        assert result is not None
        evidence = result.get("evidence")
        if not isinstance(evidence, list) or not evidence:
            return False
        if any(item.get("evidence_id") not in persisted_ids for item in evidence):
            return False
    return True


#: Desktop read actions whose successful result is an observation or an
#: artifact. The same rule as browser reads: a desktop answer that rests on a
#: capture or an inspected control tree is evidence, not narration.
DESKTOP_INSPECTION_ACTIONS: frozenset[str] = frozenset(
    {"status", "list_windows", "list_apps", "capture", "inspect_ui"}
)


#: Browser actions whose successful result is something the model observed or
#: produced, as opposed to page state it merely navigated to. A research answer
#: that rests on a page read is evidence exactly like a repository read; the
#: race's browser tasks ended "no_changes" even after a successful inspection
#: because only repository tools counted, so a pure browser answer could never
#: be reported as verified.
BROWSER_INSPECTION_ACTIONS: frozenset[str] = frozenset(
    {
        "snapshot",
        "snapshot_diff",
        "find_text",
        "get_text",
        "get_form_state",
        "page_info",
        "console",
        "network_failures",
        "network_requests",
        "cookies",
        "screenshot",
        "screenshot_region",
        "download_status",
        "download_start",
    }
)


def attempted_mutation(
    record: SessionRecord, mutating_tools: Iterable[str] = ()
) -> bool:
    """Whether any mutation tool call appears in the record.

    ``mutating_tools`` names further tools that can change something outside
    the repository -- the session's MCP tools the user did not classify as
    read-only. Such a call counts even when it failed: its effect on the
    server cannot be known, so it can never back an answer. A successful call
    Core recorded as a mutation counts as well, for a record whose binding has
    changed since.
    """
    extra = frozenset(mutating_tools)
    for entry in record.provider_history:
        if entry.get("role") != "tool":
            continue
        core_name = entry.get("core_name")
        if core_name in MUTATION_TOOLS or core_name in extra:
            return True
        result = entry.get("result")
        if (
            str(core_name or "").startswith("mcp.")
            and isinstance(result, dict)
            and result.get("mutation") is True
        ):
            return True
    return False


def answer_basis(record: SessionRecord) -> tuple[Dict[str, Any], ...]:
    """The successful inspections an answer rests on.

    Reads record no Core evidence of their own, so the basis is drawn from
    the persisted tool history, which the session store checksums as one
    document. It is reported rather than merely counted: a verified answer
    that named no source would be exactly the narrative-as-proof this
    product exists to refuse.
    """
    basis: List[Dict[str, Any]] = []
    for entry in record.provider_history:
        if entry.get("role") != "tool":
            continue
        core_name = entry.get("core_name")
        if (
            core_name != "browser.command"
            and core_name not in INSPECTION_TOOLS
            and not str(core_name or "").startswith(("desktop.", "mcp."))
        ):
            continue
        result = entry.get("result")
        if not isinstance(result, dict) or result.get("ok") is not True:
            continue
        raw_data = result.get("data")
        data: Dict[str, Any] = raw_data if isinstance(raw_data, dict) else {}
        item: Dict[str, Any] = {
            "tool": core_name,
            "call_id": str(entry.get("tool_call_id", "")),
        }
        if str(core_name or "").startswith("mcp."):
            # What a read-only MCP tool returned is something the model
            # looked at, like a page read: "read issue #7 and tell me X" was
            # never verifiable before, so every tracker or docs answer ended
            # "no_changes". Core records whether the call could mutate (the
            # user's read-only classification); a mutating call is no basis.
            if result.get("mutation") is not False:
                continue
            for key in ("server_id", "bytes"):
                value = data.get(key)
                if isinstance(value, (str, int)) and not isinstance(value, bool):
                    item[key] = value
            basis.append(item)
            continue
        if str(core_name or "").startswith("desktop."):
            action = str(core_name).split(".", 1)[1]
            if data.get("ok") is not True or action not in DESKTOP_INSPECTION_ACTIONS:
                continue
            item["action"] = action
            payload = data.get("data") if isinstance(data.get("data"), dict) else {}
            artifact = (
                payload.get("artifact")
                if isinstance(payload.get("artifact"), dict)
                else {}
            )
            for holder, key in (
                (artifact, "artifact_id"),
                (payload, "artifact_id"),
                (payload, "sha256"),
                (artifact, "sha256"),
            ):
                value = holder.get(key)
                if isinstance(value, str) and value:
                    item.setdefault(key, value)
            basis.append(item)
            continue
        if core_name == "browser.command":
            action = str(data.get("action") or "")
            if data.get("ok") is not True or action not in BROWSER_INSPECTION_ACTIONS:
                continue
            item["action"] = action
            for key in ("artifact_id", "sha256", "url", "target"):
                value = data.get(key)
                if isinstance(value, str) and value:
                    item[key] = value
            basis.append(item)
            continue
        for key in ("path", "sha256", "stdout_sha256"):
            value = data.get(key)
            if isinstance(value, str) and value:
                item[key] = value
        basis.append(item)
    return tuple(basis)


def last_provider_message(record: SessionRecord) -> Optional[str]:
    """The model's latest surviving answer text, redacted."""
    for entry in reversed(record.provider_history):
        if entry.get("role") == "assistant" and entry.get("content") is not None:
            return str(redact(entry["content"]))
    return None
