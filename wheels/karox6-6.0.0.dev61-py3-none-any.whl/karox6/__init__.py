"""KaroX 6: a small, fast coding-agent CLI."""

__version__ = "6.0.0.dev61"
