"""The shell tool: a real shell for the agent.

bash on Unix; on Windows bash from Git for Windows when installed, else PowerShell.
Each call runs in a fresh process in the workspace (or ``workdir``), stdin closed,
merged stdout/stderr, an ``[exit code: N]`` marker, a timeout that moves a still
running command to a background job instead of killing it, and tree-kill on stop.
Tool contract follows DSH's bash/pwsh tools (MIT, see THIRD_PARTY_NOTICES.md).
"""

from __future__ import annotations

import contextlib
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from karox6.context.spill import limit_output
from karox6.tools.base import ApprovalRequest, ToolContext, ToolResult
from karox6.tools.danger import check_command
from karox6.tools.proc import ProcessRun

DEFAULT_TIMEOUT_MS = 120_000
MAX_TIMEOUT_MS = 600_000
INLINE_CHARS = 30_000
PIPESTATUS_ENV = "KAROX_PIPESTATUS_FILE"

_BASH_PIPESTATUS_TRAP = (
    "trap '"
    '{ __karox_p=("${PIPESTATUS[@]+"${PIPESTATUS[@]}"}") __karox_bc=${BASH_COMMAND:-}; '
    "builtin set +x +e +u; builtin trap - DEBUG; } 2>/dev/null; "
    'case "$__karox_bc" in '
    'exit|exit[[:space:]]*|"builtin exit"|"builtin exit"[[:space:]]*|'
    '"command exit"|"command exit"[[:space:]]*) ;; '
    '*) [[ -n "${KAROX_PIPESTATUS_FILE:-}" ]] && '
    'builtin printf "%s\\n" "${__karox_p[@]}" >"$KAROX_PIPESTATUS_FILE" 2>/dev/null || true ;; '
    "esac' EXIT; "
)

_SH_PIPESTATUS_TRAP = 'if [ -n "${BASH_VERSION:-}" ]; then ' + _BASH_PIPESTATUS_TRAP + "fi; "

ENV_OVERRIDES = {
    "NO_COLOR": "1",
    "TERM": "dumb",
    "PAGER": "cat",
    "GIT_PAGER": "cat",
    "GIT_TERMINAL_PROMPT": "0",
    "PYTHONUNBUFFERED": "1",
    "PYTHONIOENCODING": "utf-8",
}


@dataclass(frozen=True, slots=True)
class ShellInfo:
    kind: Literal["bash", "pwsh"]
    executable: str
    flavor: str  # bash | git-bash | sh | pwsh | powershell

    def argv(self, command: str, script: Path | None = None) -> list[str]:
        """``script``: where Git Bash on Windows gets the command as a file. Its runtime
        parses the Windows command line itself and halves every run of backslashes inside
        quotes (a regex, a Windows path, a printf format arrived broken), and a command
        line is capped at 32767 characters; a script file has neither problem."""
        if self.kind == "bash":
            if script is not None and self.flavor == "git-bash":
                script.parent.mkdir(parents=True, exist_ok=True)
                script.write_bytes(command.encode("utf-8", "replace"))
                return [self.executable, script.as_posix()]
            return [self.executable, "-c", command]
        return [self.executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]


def detect_shell(environ: dict[str, str] | None = None) -> ShellInfo:
    env = dict(os.environ if environ is None else environ)
    override = env.get("KAROX_SHELL")
    if override:
        name = Path(override).name.lower()
        if "pwsh" in name or "powershell" in name:
            return ShellInfo("pwsh", override, "pwsh" if "pwsh" in name else "powershell")
        if sys.platform == "win32" and is_msys_bash(shutil.which(override) or override):
            return ShellInfo("bash", override, "git-bash")
        return ShellInfo("bash", override, "bash")
    if sys.platform != "win32":
        found = shutil.which("bash")
        if found:
            return ShellInfo("bash", found, "bash")
        return ShellInfo("bash", shutil.which("sh") or "/bin/sh", "sh")
    git_bash = _find_git_bash(env)
    if git_bash:
        return ShellInfo("bash", git_bash, "git-bash")
    for name in ("pwsh", "powershell"):
        found = shutil.which(name)
        if found:
            return ShellInfo("pwsh", found, name)
    return ShellInfo("pwsh", "powershell.exe", "powershell")


def is_msys_bash(path: str) -> bool:
    """A Windows bash on the MSYS/Cygwin runtime (Git Bash, MSYS2, Cygwin), which takes
    its command as a script file; not the WSL launcher (System32, WindowsApps), which
    could not open a Windows path."""
    lowered = path.replace("/", "\\").lower()
    name = lowered.rsplit("\\", 1)[-1]
    wsl = "\\windows\\system32\\" in lowered or "\\windowsapps\\" in lowered
    return name in ("bash", "bash.exe") and "\\" in lowered and not wsl


def _find_git_bash(env: dict[str, str]) -> str | None:
    """Locate Git for Windows' ``bin\\bash.exe``.

    The ``bin`` wrapper (not ``usr\\bin\\bash.exe``) sets up PATH so coreutils work
    when KaroX itself was not started from Git Bash.
    """
    upper = {k.upper(): v for k, v in env.items()}  # Windows env names are case-insensitive
    roots: list[Path] = []
    for tool in ("git", "bash"):
        found = shutil.which(tool)
        if found and not _is_wsl_launcher(found):
            roots.append(_git_root_of(Path(found)))
    for var in ("PROGRAMFILES", "PROGRAMW6432", "PROGRAMFILES(X86)"):
        if upper.get(var):
            roots.append(Path(upper[var]) / "Git")
    if upper.get("LOCALAPPDATA"):
        roots.append(Path(upper["LOCALAPPDATA"]) / "Programs" / "Git")
    for root in roots:
        for candidate in (root / "bin" / "bash.exe", root / "usr" / "bin" / "bash.exe"):
            if candidate.is_file():
                return str(candidate)
    return None


def _git_root_of(executable: Path) -> Path:
    """Map Git\\cmd\\git.exe, Git\\mingw64\\bin\\git.exe, Git\\usr\\bin\\bash.exe to Git."""
    path = executable.resolve().parent  # the bin/cmd directory
    while path.name.lower() in ("bin", "cmd", "mingw64", "mingw32", "clangarm64", "usr"):
        if path.parent == path:
            break
        path = path.parent
    return path


def _is_wsl_launcher(path: str) -> bool:
    lowered = path.lower().replace("/", "\\")
    return "\\system32\\" in lowered or "\\windowsapps\\" in lowered


def shell_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = dict(os.environ)
    env.update(ENV_OVERRIDES)
    if extra:
        env.update(extra)
    return env


def wrap_command_for_pipestatus(
    command: str, shell: ShellInfo, status_path: Path | None
) -> tuple[str, dict[str, str]]:
    """Wrap a bash/sh command to record the last pipeline's ``PIPESTATUS`` into ``status_path``.

    Leaves PowerShell unchanged and falls back to the unwrapped command on any error.
    """
    if shell.kind != "bash" or status_path is None:
        return command, {}
    try:
        target = status_path.resolve().as_posix()
    except OSError:
        return command, {}
    prefix = _SH_PIPESTATUS_TRAP if shell.flavor == "sh" else _BASH_PIPESTATUS_TRAP
    return f"{prefix}{command}", {PIPESTATUS_ENV: target}


def read_pipestatus(status_path: Path | None) -> list[int] | None:
    """Read and remove the recorded ``PIPESTATUS`` side-channel file; None on any failure."""
    if status_path is None:
        return None
    try:
        raw = status_path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    finally:
        with contextlib.suppress(OSError):
            status_path.unlink(missing_ok=True)
    if not raw:
        return None
    codes: list[int] = []
    for token in raw.split():
        try:
            codes.append(int(token))
        except ValueError:
            return None
    return codes or None


def format_exit_marker(
    returncode: int | None, pipestatus: list[int] | None
) -> tuple[str, list[int] | None]:
    """Build ``[exit code: N]``, optional signal hint, and ``[pipeline exit codes: ...]``."""
    marker = f"[exit code: {returncode}]"
    if (
        returncode is not None
        and pipestatus
        and 129 <= returncode <= 192
        and pipestatus[-1] == returncode
    ):
        sig = returncode - 128
        marker = f"{marker} (128+{sig}, likely signal {sig})"
    if pipestatus and len(pipestatus) > 1:
        # Ignore SIGPIPE (141) in non-last stages unless pipefail made the pipeline exit non-zero.
        non_last_fail = any(code not in (0, 141) for code in pipestatus[:-1])
        if (
            non_last_fail
            or pipestatus[-1] != 0
            or (returncode is not None and returncode != pipestatus[-1])
        ):
            joined = " ".join(str(code) for code in pipestatus)
            return f"{marker} [pipeline exit codes: {joined}]", pipestatus
    return marker, None


class ShellTool:
    read_only = False

    def __init__(self, shell: ShellInfo) -> None:
        self.shell = shell
        self.name = "bash" if shell.kind == "bash" else "pwsh"
        self.description = _description(shell)
        self.parameters: dict[str, Any] = {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The command to run."},
                "description": {
                    "type": "string",
                    "description": "Five to ten words on what the command does.",
                },
                "timeout": {
                    "type": "integer",
                    "description": f"Timeout in ms (default {DEFAULT_TIMEOUT_MS}, "
                    f"max {MAX_TIMEOUT_MS}).",
                },
                "workdir": {
                    "type": "string",
                    "description": "Directory to run in (default: the workspace root).",
                },
                "run_in_background": {
                    "type": "boolean",
                    "description": "Start as a background job and return at once "
                    "(servers, watchers, long builds).",
                },
            },
            "required": ["command"],
        }

    async def run(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        command = str(args["command"])
        if not command.strip():
            return ToolResult("Error: empty command.", is_error=True)
        cwd = ctx.workspace
        if args.get("workdir"):
            cwd = ctx.resolve(str(args["workdir"]))
            if not cwd.is_dir():
                return ToolResult(f"Error: workdir {cwd} is not a directory.", is_error=True)
        raw_timeout = args.get("timeout", args.get("timeoutMs", args.get("timeout_ms")))
        timeout_ms = DEFAULT_TIMEOUT_MS
        if raw_timeout is not None:
            try:
                timeout_ms = int(raw_timeout)
            except (TypeError, ValueError):
                timeout_ms = DEFAULT_TIMEOUT_MS
        timeout_ms = min(max(timeout_ms, 1_000), MAX_TIMEOUT_MS)
        if ctx.command_wait_cap_s is not None:
            # Past the cap the command keeps running as a job: the model gets control back
            # (to read its output so far, wait more or kill a hang) instead of blocking.
            timeout_ms = min(timeout_ms, max(ctx.command_wait_cap_s, 1) * 1000)

        danger = check_command(command, shell=self.shell.kind, cwd=cwd, workspace=ctx.workspace)
        if danger is not None:
            approved = await ctx.approve(
                ApprovalRequest(
                    tool=self.name, summary=command, rule=danger.rule, reason=danger.reason
                )
            )
            if not approved:
                return ToolResult(
                    f"Not executed: this command matches the destructive-command rule "
                    f"'{danger.rule}' ({danger.reason}) and the user did not confirm it. "
                    "Do not retry it in another form; use a narrower command (for example "
                    "delete specific paths inside the workspace) or leave this step to the user.",
                    is_error=True,
                    meta={"blocked_rule": danger.rule},
                )

        log_dir = ctx.session_dir / "shell"
        index = len(list(log_dir.glob("*.log"))) + 1 if log_dir.exists() else 1
        log_path = log_dir / f"cmd-{index:04d}.log"
        background = bool(args.get("run_in_background"))
        pipestatus_path = (
            log_path.with_suffix(".pipestatus")
            if self.shell.kind == "bash" and not background
            else None
        )
        wrapped_command, extra_env = wrap_command_for_pipestatus(
            command, self.shell, pipestatus_path
        )
        run_env = {**ctx.env, **extra_env} if extra_env else ctx.env
        try:
            # Claim the number before the first await: a concurrent call (MCP direct mode)
            # would otherwise count the same logs and share this log and script file.
            log_dir.mkdir(parents=True, exist_ok=True)
            log_path.touch()
            run = await ProcessRun.start(
                self.shell.argv(wrapped_command, script=log_path.with_suffix(".sh")),
                cwd=cwd,
                env=shell_env(run_env),
                log_path=log_path,
                command=command,
            )
        except OSError as exc:
            return ToolResult(
                f"Error: could not start {self.shell.executable}: {exc}", is_error=True
            )

        if background:
            job = ctx.jobs.register(run)
            return ToolResult(
                f"Started background job {job.id} (pid {run.pid}). Output is written to "
                f"{log_path}. Use job_output with job_id {job.id} to read it and job_kill "
                "to stop it.",
                meta={"job_id": job.id, "pid": run.pid},
            )

        try:
            # A wait never outlasts the run's time limit; the command keeps running as a
            # background job, as on any timeout.
            waited_s = ctx.wait_cap_s(timeout_ms / 1000)
            finished = await run.wait(waited_s)
        except BaseException:  # the run was cancelled: the command must not outlive it
            await run.kill_on_cancel()
            with contextlib.suppress(OSError):
                if pipestatus_path is not None:
                    pipestatus_path.unlink(missing_ok=True)
            raise
        text, _complete = run.output_text()
        if finished:
            pipestatus = read_pipestatus(pipestatus_path)
            marker, reported_pipe = format_exit_marker(run.returncode, pipestatus)
            meta: dict[str, Any] = {"exit_code": run.returncode}
            if reported_pipe is not None:
                meta["pipeline_exit_codes"] = reported_pipe
            if run.active:  # a process it started (`server &`) still writes to the output
                job = ctx.jobs.register(run)
                job.read_offset = run.total_bytes
                pipe_suffix = (
                    f" [pipeline exit codes: {' '.join(str(c) for c in reported_pipe)}]"
                    if reported_pipe is not None
                    else ""
                )
                marker = (
                    f"[exit code: {run.returncode}; a process it started is still running and "
                    f"writing to this output: background job {job.id}. Use job_output to "
                    f"read it, job_kill to stop it.]{pipe_suffix}"
                )
                meta["job_id"] = job.id
        else:
            if pipestatus_path is not None:
                with contextlib.suppress(OSError):
                    pipestatus_path.unlink(missing_ok=True)
                run.cleanup_on_exit(pipestatus_path)
            job = ctx.jobs.register(run)
            job.read_offset = run.total_bytes
            marker = (
                f"[still running after {int(waited_s * 1000)} ms; moved to background job "
                f"{job.id}. "
                "Use job_output to read more output or wait for it, job_kill to stop it.]"
            )
            meta = {"job_id": job.id, "timed_out": True}
        inline, spill = limit_output(
            text,
            spill_dir=ctx.spill_dir,
            name=self.name,
            max_chars=INLINE_CHARS,
            full_path=log_path,
        )
        if spill is not None:
            meta["spill_path"] = str(spill)
        body = inline if inline.endswith("\n") or not inline else inline + "\n"
        return ToolResult(f"{body}{marker}", meta=meta)


def _description(shell: ShellInfo) -> str:
    common = (
        " Each call runs in a fresh process with stdin closed, in the workspace root unless "
        "`workdir` is given (prefer `workdir` over `cd`). Output is stdout and stderr merged, "
        "followed by an `[exit code: N]` marker; check it and investigate failures before "
        f"moving on. Default timeout {DEFAULT_TIMEOUT_MS} ms (max {MAX_TIMEOUT_MS}); a command "
        "still running at its timeout keeps running as a background job instead of being "
        "killed. Use `run_in_background` for servers and watchers, then job_output/job_kill. "
        "Long output keeps its head and tail; the full output is saved to a file whose path is "
        "reported. Never start interactive programs (editors, pagers, prompts). Before any "
        "delete or move, check that the target path is the intended one."
    )
    if shell.kind == "bash":
        intro = "Execute a bash command (`bash -c`) and return its output."
        if shell.flavor == "git-bash":
            intro += (
                " This is Git Bash on Windows: use POSIX shell syntax; write Windows paths as "
                "`/c/Users/...` or `C:/Users/...`."
            )
        elif shell.flavor == "sh":
            intro = "Execute a POSIX sh command (`sh -c`) and return its output."
        pipe_note = (
            " When the last pipeline has multiple stages and any stage exits non-zero, "
            "`[pipeline exit codes: ...]` is appended to the exit marker."
        )
        return intro + common + pipe_note
    return (
        "Execute a PowerShell command (`-Command`) and return its output. Paths use native "
        "Windows form (`C:\\...`); read environment variables with `$env:NAME`. On Windows a "
        "force-killed command settles as `[exit code: 1]`." + common
    )
